document.addEventListener("DOMContentLoaded", () => {
  console.log("Author's Purpose site loaded ✅");
});
